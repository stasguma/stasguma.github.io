## [resume](https://stasguma.github.io/resume/index.html) (click)
